import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { useTranslation } from 'react-i18next';
import Header from './components/Layout/Header';
import Footer from './components/Layout/Footer';
import Home from './pages/Home';
import Services from './pages/Services';
import Booking from './pages/Booking';
import Login from './pages/Login';
import Dashboard from './components/Dashboard/Dashboard';
import './i18n/config';

function App() {
  const { ready } = useTranslation();

  if (!ready) {
    return (
      <div className="min-h-screen bg-warm-gray flex items-center justify-center">
        <div className="text-forest-green">Chargement...</div>
      </div>
    );
  }

  return (
    <Router>
      <div className="min-h-screen bg-warm-gray flex flex-col">
        <Header />
        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/services" element={<Services />} />
            <Route path="/booking" element={<Booking />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;